/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import java.util.Scanner;

/**
 *
 * @author douyo
 */
public class Bank {
    
    private static ArrayList<AutomatedTellerMachine> atms = new ArrayList<>(){
    private static ArrayList<User> users = new ArrayList<>();
    
    public static void addUser(String userName, String password){
        users.add(new User(userName, password));
        
    }
    
    public static ArrayList<User> getUsers(){
        return users;
    }
    
    public void printWelcome(){
        System.out.println("Welcome to use our ATM");
    }
    
    public User readUserId(){
        Scanner console = new Scanner(System.in);
        
        System.out.println("Please enter your user ID");
        String inputId = console.next();
        
        for (int i = 0; i < Bank.getUsers().size(); i++)
            if(inputId.equals(Bank.getUsers().get(i).getUserId()))
                return Bank.getUsers().get(i);
        
        return null;
    }
    
    public boolean inputPin(User user){
        Scanner console = new Scanner(System.in);
        int maxTry = 3;
        
        for (int i = 0; i < maxTry; i++){
            System.out.println("Please enter user password");
            String password = console.next();
            if (user.getPassword().equals(password))
                return true;
            System.out.println("Your password is wrong");
        }
        System.out.println("Your input password wrong for 3 times");
        return false;
        }
    }
            
    public Account chooseAccount (User user){
         Scanner console = new Scanner(System.in);
            
         System.out.println("Please choose the account you want to operate with"
                    + "\n\t1. Checking account"
                    + "\n\t2. Saving account");
         int accountChoice = console.nextInt();
            
         return accountChoice == 1 ? user.getCheckingAccount() : user.getSaving Acount();
}
    
    public int chooseOperation(){
            Scanner console = new Scanner(System.in);
            
         System.out.println("Please choose the operation"
                 + "\n\t1. Withdraw"
                 + "\n\t1. Deposit"
                 + "\n\t1. Display balance");
         int operation = console.nextInt();
            
         return operation;
    }
    
    public boolean withdraw(Account account){
        Scanner console = new Scanner(System.in);
        
        System.out.println("How much do you want to withdraw? ");
        double amount = console.nextDouble();
        if(account.getBalance() < amount){
            System.out.println("Sorry, you don't have enough balance.");
            return false;
        }
        account.setBalance(account.getBalance() - amount);
        System.out.println("Withdraw successfully");
        return true;
    }
    
    public void displayBalance(Account account){
        System.out.println("Your current balance is $%.2f", account.getBalance());
    }
    
    public void printGoodBye(){
        System.out.println("Thank you for using out ATM. Goodbye");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
