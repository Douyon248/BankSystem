/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package user;

/**
 *
 * @author douyo
 */
public class Account {
    
    private char type;
    private double balance;
    
    public Account() {
        this.type = 'c';
        this.balance = 0;
    }
    
    public Account(char type, double balance) {
        this.type = type;
        this.balance = balance;
    }
    
    public Account(Account account) {
        this.type = account.type;
        this.balance = account.balance;
    }
}
